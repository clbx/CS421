
public enum DataType { none, inttype, realtype, booleantype, methodAddr

}
