
public enum Allocation { noAllocation, classAllocation, methodAllocation, staticAllocation

}
